package com.insidercloud.airlinereservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineReservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
