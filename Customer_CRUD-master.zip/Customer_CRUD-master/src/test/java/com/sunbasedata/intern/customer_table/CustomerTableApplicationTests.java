package com.sunbasedata.intern.customer_table;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerTableApplicationTests {

	@Test
	void contextLoads() {
	}

}
