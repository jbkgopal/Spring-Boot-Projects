package com.dhanush.airline.exception;

public class BookingRestControllerExceptionHandler {

}
