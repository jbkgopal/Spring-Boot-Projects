package database;

public enum UserType {
    Librarian,
    Reader,
    Admin
}
