package com.airlines.automationsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomationsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
