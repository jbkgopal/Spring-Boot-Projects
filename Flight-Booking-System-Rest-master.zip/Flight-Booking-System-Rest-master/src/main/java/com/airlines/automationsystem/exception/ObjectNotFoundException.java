package com.airlines.automationsystem.exception;


public class ObjectNotFoundException extends RuntimeException {

    public ObjectNotFoundException(String exception) {
        super(exception);
    }
}
