# Basic-Banking-System-Grip
#  Click <a href="https://incrust-jam.000webhostapp.com/">here</a>
Sparks Foundation Web Development Internship Project 
Task 1: Basic Banking System website. 
Batch: April 2022 #GRIPAPRIL2022
A web application that is used to tranfer money online between multiple users and also record the transaction history.
